package notepad_clone;

//Import necessary libraries for GUI, file handling and event handling
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Notepad 
{
	// Main components of Note pad
	JFrame frame;
	JTextArea textArea;
	JMenuBar menuBar;
	JMenu fileMenu, languageMenu, formatMenu, commandPromptMenu;
	
	//File Menu Items
	JMenuItem itemNew, itemNewWindow, itemOpen, itemSave, itemSaveAs, itemExit;
	
	//Format Menu Items
	JMenuItem itemWordWrap,itemFont,itemFontSize;
	
	//Command Prompt Item
	JMenuItem itemCMD;


	// Variables for file handling operations
	String openFileName = null;  // Path of current file
	String openPath = null;	// Name of current file
	boolean wrap = false;  //word wrap status
	
	// font and font style 
	Font arial, timesNewRoman, consolas;
	String fontStyle = "arial";
	
	//Main method to launch note pad application
	public static void main(String[] args) 
	{
		Notepad n1 = new Notepad();
	}

	// Constructor to initialize the note pad application
	public Notepad() {
		createFrame();      //Create main frame
		createTextArea();	//add text area
		createScrollBars();		// add  Scroll bars to the text area 
		createMenuBar();		//add menu bar
		createFileMenuItems();		//add items to file menu
		createLanguageItems();		//add items to Language Menu
		createFormatMenuItems();	//add items to format menu
		createCommandPrompt();  	//add functionality for CMD
		
	}


	public void createFrame()  //method design to create new frame
	{	
		frame = new JFrame("Notepad");    // name given to frame
		
		frame.setSize(500,300);  //set size of frame
		Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Javaproject\\notebook.png");   
		
		frame.setIconImage(icon);
		frame.setVisible(true);     
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);   // window gets dispose while closing window
	}
	
	public void createTextArea()       //design method to create text area
	{
		textArea = new JTextArea();
		textArea.setFont(new Font("Arial",Font.PLAIN,18));   //set default font of text area
		frame.add(textArea);
	}
	
	public void createScrollBars() 
	{
		JScrollPane scroll = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(textArea);
	}
	
	// file handling components cv
	public void createMenuBar()  	//creating menu Bar and adding content to it
	{
		menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);  //create menu bar
		
		fileMenu = new JMenu("File");  // create and add file menu
		menuBar.add(fileMenu);
		
		languageMenu = new JMenu("Languge");  	//create and add Language menu
		menuBar.add(languageMenu);
		
		formatMenu = new JMenu("Format");		//create and add Format menu
		menuBar.add(formatMenu);
		
		commandPromptMenu = new JMenu("Command Prompt");	//create and add CMD menu
		menuBar.add(commandPromptMenu);	
	}
	
	
	//method to create and add File handle menu Items
		public void createFileMenuItems() 
		{	
			itemNew = new JMenuItem("New");
			
			itemNew.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					textArea.setText("");
					frame.setTitle("Untitle");   //create new text area which is untitled
					
					openFileName = null;
					openPath = null;
					
				}
			});
			fileMenu.add(itemNew);
			
			
			itemNewWindow = new JMenuItem("New Window");  //add new window
			itemNewWindow.addActionListener(new ActionListener() 
			{
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					Notepad n2 =  new Notepad();  //add new window in frame
					n2.frame.setTitle("Untiteled");		
				}
			});
			
			fileMenu.add(itemNewWindow);
			
			
			
			itemOpen = new JMenuItem("Open");     //open option
			itemOpen.addActionListener(new ActionListener()   //open an existing file
			{
				
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					FileDialog fd = new FileDialog(frame,"open", FileDialog.LOAD);// to display file store window and to open(read) selected file where we save files
					
					fd.setVisible(true);      //
					
					String path = fd.getDirectory();  //to get path in string format
					String filename = fd.getFile();
					
					//System.out.println(filename);
					
					if (filename!=null)
					{
						frame.setTitle(path+filename);
						
						openFileName = filename;
						openPath = path;
					}
					System.out.println(path+filename);   //after open--->path & filename will display
					
					
					//read the file and display its content in text area
					BufferedReader br = null;
					try
					{
						br = new BufferedReader(new FileReader(path+filename));
						
						String sentence = br.readLine();
						textArea.setText("");  //clear current text
						while(sentence!= null)
						{
							textArea.append(sentence+"\n");
							sentence = br.readLine();
						 }
					}
					catch(FileNotFoundException e1)
					{
						System.out.println("File not found");
					}
					catch(IOException e1) 
					{
						System.out.println("Data could not be read");
					}
					catch(NullPointerException e2) 
					{
						
					}
					finally 
						{
							try {
							br.close();
							} 
							catch (IOException e1) 
							{
								System.out.println("File could not be close");
							}
							catch(NullPointerException e2)
							{
								
							}
							
						}
					
				}
			} );
			
			fileMenu.add(itemOpen);
			
			
			
			itemSave = new JMenuItem("Save");
			
			itemSave.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					if(openFileName!=null && openPath!=null)   
					{
						writeDataToFile(openFileName, openPath);  //if executes for--->to save newly added data into already saved  file
					}
					else             
					{                             
						FileDialog fd = new FileDialog(frame, "Save As", FileDialog.SAVE);
						fd.setVisible(true);                 //else executes---> to save fresh file 
						
						String path = fd.getDirectory();   
						String filename = fd.getFile()	;
						
						if(path!= null && filename!= null) 
						{
							writeDataToFile(filename, path);
							
							openFileName = filename;
							openPath = path;
							
							frame.setTitle(openPath);						}
					}
					
				}
			});
			
			fileMenu.add(itemSave);
			
			itemSaveAs = new JMenuItem("SaveAs");
			
			itemSaveAs.addActionListener( new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e)
				{
					FileDialog fd = new FileDialog(frame, "Save As", FileDialog.SAVE);
					fd.setVisible(true);
					
					String path = fd.getDirectory();
					String filename = fd.getFile()	;
					
					if(path!= null && filename!= null)
					{
						writeDataToFile(filename, path);
						
						openFileName = filename;
						openPath = path;
						
						frame.setTitle(openPath+filename);	
					}			
				}
			});
			fileMenu.add(itemSaveAs);
			
			
			itemExit = new JMenuItem("Exit");
			
			itemExit.addActionListener(new ActionListener() 
			{
				
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					frame.dispose();	
				}
			});
			fileMenu.add(itemExit);	
		}
		
		//method to create language items
		//add Java, C, CPP, HTML option for boiler plate code
	public void createLanguageItems()
		{
			JMenuItem itemJava = new JMenuItem("java");
			
			itemJava.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					setLanguage("Java");
					
					
				}
			});
			languageMenu.add(itemJava);
			
			JMenuItem itemHTML = new JMenuItem("HTML");
			itemJava.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					setLanguage("Html");
				
				}
			});
			languageMenu.add(itemHTML);
			
			JMenuItem itemC = new JMenuItem("C");
			itemJava.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					setLanguage("C");
					
				}
			});
			languageMenu.add(itemC);
			
			
			JMenuItem itemCpp = new JMenuItem("C++");
			itemJava.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					setLanguage("Cpp");
				
				}
			});
			languageMenu.add(itemCpp);
				
			
		}
		
		//method to crate language specific template
		public void setLanguage(String lang)
		{
			BufferedReader br = null;
			try
			{
				br = new BufferedReader(new FileReader("D:\\Javaproject\\filehandle\\"+lang+"boilercode.txt"));
				
				String sentence = br.readLine();
				textArea.setText("");
				while(sentence!= null)
				{
					textArea.append(sentence+"\n");
					sentence = br.readLine();
				 }
			}
			catch(FileNotFoundException e1)
			{
				System.out.println("File not found");
			}
			catch(IOException e1) 
			{
				System.out.println("Data could not be read");
			}
			catch(NullPointerException e2) 
			{
				
			}
			finally 
				{
					try 
					{
					br.close();
					} 
					catch (IOException e1) 
					{
						System.out.println("File could not be close");
					}
					catch(NullPointerException e2)
					{
						
					}
				}
					
		}
		
	//Method to create and handle format menu items
	public void createFormatMenuItems()
	{
		itemWordWrap = new JMenuItem("WordWrap: OFF");   //word wrap toggle
		formatMenu.add(itemWordWrap);
		
		itemWordWrap.addActionListener(new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				if(wrap==false) {
					
					textArea.setLineWrap(true);
					textArea.setWrapStyleWord(true);
					wrap = true;
					itemWordWrap.setText("Word wrap on");
				}
				else {
					textArea.setLineWrap(false);
					textArea.setWrapStyleWord(false);
					wrap = false;
					itemWordWrap.setText("Word wrap off");	
				}
				
			
			}
		});
		
		// add font and font size customization
		itemFont = new JMenu("Font");	
		formatMenu.add(itemFont);
		
		JMenuItem itemArial = new JMenuItem("Arial");
		
		itemArial.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontType("Arial");
			}
		});
		itemFont.add(itemArial);
		
		JMenuItem itemTimesNewRoman = new JMenuItem("Times New Roman");
		itemTimesNewRoman.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				setFontType("Times New Roman");
			}
		});
		itemFont.add(itemTimesNewRoman);
		
		JMenuItem itemConsolas = new JMenuItem("Consolas");
		itemConsolas.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				setFontType("Consolas");
			}
		});
		itemFont.add(itemConsolas);
		
		
		
			
		itemFontSize = new JMenu("Font Size");
		formatMenu.add(itemFontSize);	
		
		JMenuItem size10 = new JMenuItem("10");
		size10.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(10);
			}
		});
		itemFontSize.add(size10);
		
		
		JMenuItem size14 = new JMenuItem("14");
		size14.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(14);
			}
		});
		itemFontSize.add(size14);
		
		JMenuItem size18 = new JMenuItem("18");
		size18.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(18);
			}
		});
		itemFontSize.add(size18);
		
		JMenuItem size20 = new JMenuItem("20");
		size20.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(20);
			}
		});
		itemFontSize.add(size20);
		
		JMenuItem size24 = new JMenuItem("24");
		size24.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(24);
			}
		});
		itemFontSize.add(size24);
		
		JMenuItem size26 = new JMenuItem("26");
		size26.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(26);
			}
		});
		itemFontSize.add(size26);
		
		JMenuItem size30 = new JMenuItem("30");
		size30.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(30);
			}
		});
		itemFontSize.add(size30);
		
		JMenuItem size34 = new JMenuItem("34");
		
		size34.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setFontSize(34);
			}
		});
		itemFontSize.add(size34);
		
	}
	
	public void setFontSize(int size) {
		
		arial =  new Font("Arial", Font.PLAIN, size); 
		timesNewRoman =  new Font("Times New Roaman", Font.PLAIN, size); 
		consolas =  new Font("Consolas", Font.PLAIN, size); 
		
		setFontType(fontStyle);
	}
		//design method for accept string
		//put it in switch case
		//1st case===aerial
		// 2nd case==times
		//3rd case == console
		//when user choose case2...it will pass in
		
	public void setFontType(String font)
	{
		fontStyle = font;
		
		switch(font) 
		{
			case "Arial":
				textArea.setFont(arial);
				break;
				
			case "Times New Roman":
				textArea.setFont(timesNewRoman);
				break;
			
			case "Consolas":
				textArea.setFont(consolas);
				break;
				
			default:
					break;
			
		}
	}
		
	
	
	// method to create CMD
	public void createCommandPrompt()
	{
		itemCMD = new JMenuItem("Open Cmd");

		itemCMD.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					
					if(openPath!=null)
					{
						Runtime.getRuntime().exec(new String[] {"cmd","/k","start"},null, new File(openPath));
					}
					else 
					{
						Runtime.getRuntime().exec(new String[] {"cmd","/k","start"},null, null);
					}
				}
				catch(IOException e1) 
				{
					System.out.println("Could not launch CMD");
					
				}
			}	
			
		});
		
		commandPromptMenu.add(itemCMD);
		
		
	}
	
	//write data in existence file
	public void writeDataToFile( String filename, String path) 
	{
		BufferedWriter bw = null;
		try 
		{
			bw = new BufferedWriter(new FileWriter(path+filename));
		
			String text = textArea.getText();
			
			bw.write(text);
		}
		catch(IOException e1) 
		{
			System.out.println("File not found"); 
		}
		catch(NullPointerException e2) {
			System.out.println("File not found to write data");  //file is not there to 
		}
		finally 
		{
			try 
			{
				bw.close();
			}
			catch(IOException e1) 
			{
				System.out.println("File can not be close");
			}
			catch(NullPointerException e2 )
			{
				System.out.println("File not found to close");
			}
				
		}
				
	}
	
	public void cerateLanguageItems()
	{
		JMenuItem itemJava = new JMenuItem("Java");
		
		itemJava.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setLanguage("Java");
				openPath= null;
				openFileName = null;
				
			}
		});
		languageMenu.add(itemJava);
		
		JMenuItem itemC = new JMenuItem("C");
		
		itemJava.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setLanguage("C");
				openPath= null;
				openFileName = null;
				
			}
		});
		languageMenu.add(itemC);
		
		JMenuItem itemCpp = new JMenuItem("C++");
		
		itemJava.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setLanguage("Cpp");
				openPath= null;
				openFileName = null;
				
			}
		});
		languageMenu.add(itemCpp);
		
		JMenuItem itemHtml = new JMenuItem("Html");
		
		itemJava.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setLanguage("Html");
				openPath= null;
				openFileName = null;
				
			}
		});
		languageMenu.add(itemHtml);
		
	}
	
}	

