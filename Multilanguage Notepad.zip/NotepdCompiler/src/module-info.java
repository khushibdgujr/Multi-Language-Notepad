/**
 * 
 */
/**
 * 
 */
module NotepdCompiler {
	requires java.desktop;
}